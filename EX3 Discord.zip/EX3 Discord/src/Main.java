import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Main {
    public static void main(String[] args) {

        List<Mensagem> historicoMensagem = new ArrayList<>();
        List<Usuario> usuariosCadastrados = new ArrayList<>();


        //Teste servidor, mensagem e usuário
        Servidor servidor1 = new Servidor("Servidor teste",usuariosCadastrados, historicoMensagem );


        Usuario usuario1 = new Usuario("Luann", 556);
        usuariosCadastrados.add(usuario1);

        Mensagem mensagem1 = new Mensagem("Luann", "Olá mundo", 720);
        historicoMensagem.add(mensagem1);

        System.out.println(servidor1);


        //Dialogo Alice e Bob

        Usuario Alice = new Usuario("Alice", 558);
        usuariosCadastrados.add(Alice);

        Mensagem mensagemAlice1 = new Mensagem("Alice", "Olá Bob, tudo bem?", 860);
        historicoMensagem.add(mensagemAlice1);

        Usuario Bob = new Usuario("Bob", 569);
        usuariosCadastrados.add(Bob);

        Mensagem mensagemBob1 = new Mensagem("Bob", "Olá Alice, tudo sim e você?", 870);
        historicoMensagem.add(mensagemBob1);

        Mensagem mensagemAlice2 = new Mensagem("Alice", "Estou bem também, olá pessoal!", 875 );
        historicoMensagem.add(mensagemAlice2);

        Mensagem mensagemBob2 = new Mensagem("Bob", "Olá pessoal!", 880);

        //Sout de mensagens e usuario no servidor

        Servidor servidorAliceBob = new Servidor("Estudos programação", usuariosCadastrados, historicoMensagem);

        System.out.println(servidorAliceBob);


        //Stream api
        //Consulta avançada de mensagens

        List<Mensagem> filtroAutor = historicoMensagem.stream()
                .filter(m->m.getAutor().equals("Alice"))
                .toList();
        filtroAutor.forEach(System.out::println);

        List<Mensagem> dataHora = historicoMensagem.stream()
                .filter();

    }
}


