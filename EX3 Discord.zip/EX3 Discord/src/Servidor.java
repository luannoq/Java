import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Servidor  {
    private String nomeServidor;
    private List<Usuario> usuariosServidor;
    private List<Mensagem> historicoMensagem;


    //Metodo para adicionar usuario

    //Metodo para remover usuario


    //Construtor vazio

    public Servidor() {
    }

    //Construtor completo

    public Servidor(String nomeServidor, List<Usuario> usuariosServidor, List<Mensagem> historicoMensagem) {
        this.nomeServidor = nomeServidor;
        this.usuariosServidor = usuariosServidor;
        this.historicoMensagem = historicoMensagem;
    }

    //Getters e setters

    public String getNomeServidor() {
        return nomeServidor;
    }

    public void setNomeServidor(String nomeServidor) {
        this.nomeServidor = nomeServidor;
    }

    public List<Usuario> getUsuariosServidor() {
        return usuariosServidor;
    }

    public void setUsuariosServidor(List<Usuario> usuariosServidor) {
        this.usuariosServidor = usuariosServidor;
    }

    public List<Mensagem> getHistoricoMensagem() {
        return historicoMensagem;
    }

    public void setHistoricoMensagem(List<Mensagem> historicoMensagem) {
        this.historicoMensagem = historicoMensagem;
    }

    //Equals e Hashcode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Servidor servidor = (Servidor) o;
        return Objects.equals(getNomeServidor(), servidor.getNomeServidor()) && Objects.equals(getUsuariosServidor(), servidor.getUsuariosServidor()) && Objects.equals(getHistoricoMensagem(), servidor.getHistoricoMensagem());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNomeServidor(), getUsuariosServidor(), getHistoricoMensagem());
    }

    //To string


    @Override
    public String toString() {
        return "Servidor{" +
                "nomeServidor='" + nomeServidor + '\'' +
                ", usuariosServidor=" + usuariosServidor +
                ", historicoMensagem=" + historicoMensagem +
                '}';
    }
}

