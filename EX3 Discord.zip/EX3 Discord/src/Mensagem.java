import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Mensagem {
    private String autor;
    private String conteudo;
    private double dataHora;



    //Construtor vazio

    public Mensagem() {
    }

    //Construtor completo

    public Mensagem(String autor, String conteudo, double dataHora) {
        this.autor = autor;
        this.conteudo = conteudo;
        this.dataHora = dataHora;
    }

    //Getters e setters

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public double getDataHora() {
        return dataHora;
    }

    public void setDataHora(double dataHora) {
        this.dataHora = dataHora;
    }

    //Equals e hashcode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Mensagem mensagem = (Mensagem) o;
        return Double.compare(getDataHora(), mensagem.getDataHora()) == 0 && Objects.equals(getAutor(), mensagem.getAutor()) && Objects.equals(getConteudo(), mensagem.getConteudo());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAutor(), getConteudo(), getDataHora());
    }

    //To string

    @Override
    public String toString() {
        return "Mensagem{" +
                "autor='" + autor + '\'' +
                ", conteudo='" + conteudo + '\'' +
                ", dataHora=" + dataHora +
                '}';
    }
}


