import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Usuario {
    private String nome;
    private double ID;


    //Construtor vazio

    public Usuario() {
    }

    //Construtor completo

    public Usuario(String nome, double ID) {
        this.nome = nome;
        this.ID = ID;
    }


    //Getters e Setters

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getID() {
        return ID;
    }

    public void setID(double ID) {
        this.ID = ID;
    }

    //Equals e hashcode

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return Double.compare(getID(), usuario.getID()) == 0 && Objects.equals(getNome(), usuario.getNome());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNome(), getID());
    }

    // To string

    @Override
    public String toString() {
        return "Usuario{" +
                "nome='" + nome + '\'' +
                ", ID=" + ID +
                '}';
    }
}
