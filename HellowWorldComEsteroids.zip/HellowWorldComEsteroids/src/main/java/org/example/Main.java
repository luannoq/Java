package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        var carta = new Carta();

        //AnnotationProcessor.processDataFields(carta);
        //System.out.println(carta);
    }
}